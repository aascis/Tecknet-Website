#!/bin/bash
# update.sh - Update script for the SaaS platform

# Exit on error
set -e

# Default deployment directory
DEPLOY_DIR="/var/www/cloudservice"

# Display help if requested
if [ "$1" == "-h" ] || [ "$1" == "--help" ]; then
  echo "Usage: ./update.sh [options]"
  echo "Options:"
  echo "  --dir=/path/to/dir    Specify deployment directory (default: $DEPLOY_DIR)"
  echo "  --help                Display this help message"
  exit 0
fi

# Parse arguments
for arg in "$@"; do
  case $arg in
    --dir=*)
    DEPLOY_DIR="${arg#*=}"
    shift
    ;;
    *)
    # Unknown option
    ;;
  esac
done

echo "=== SaaS Platform Update ==="
echo "Deployment directory: $DEPLOY_DIR"
echo

# Navigate to deployment directory
cd $DEPLOY_DIR

# Backup .env file
echo "Backing up .env file..."
cp .env .env.backup

# If using Git
if [ -d ".git" ]; then
  echo "Updating from Git repository..."
  git pull
else
  echo "No Git repository found. Please upload new files manually before running this script."
  echo "Proceeding with update process..."
fi

# Install dependencies
echo "Installing dependencies..."
npm install

# Build the application
echo "Building the application..."
sh $DEPLOY_DIR/build.sh

# Apply database migrations if needed
echo "Applying database migrations..."
npm run db:push

# Restart the application
echo "Restarting the application..."
if command -v pm2 &> /dev/null; then
  pm2 restart cloudservice
else
  echo "PM2 not found. Please restart the application manually."
fi

echo "=== Update complete! ==="
echo "Your SaaS platform has been updated."
echo
echo "If you encounter any issues, you can restore your .env backup with:"
echo "  cp $DEPLOY_DIR/.env.backup $DEPLOY_DIR/.env"