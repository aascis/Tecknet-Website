import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { getQueryFn } from "@/lib/queryClient";
import { Subscription, Ticket } from "@shared/schema";
import {
  CreditCard,
  Users,
  FileText,
  MessageSquare,
  Calendar,
  Server,
} from "lucide-react";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import Navbar from "@/components/Navbar";
import { Link } from "wouter";

export default function CustomerDashboard() {
  const { user } = useAuth();

  // Fetch customer subscriptions
  const {
    data: subscriptions,
    isLoading: subscriptionsLoading,
    error: subscriptionsError,
  } = useQuery<Subscription[]>({
    queryKey: ["/api/subscriptions"],
    enabled: !!user,
  });

  // Fetch customer tickets
  const {
    data: tickets,
    isLoading: ticketsLoading,
    error: ticketsError,
  } = useQuery<Ticket[]>({
    queryKey: ["/api/tickets"],
    enabled: !!user,
  });

  // Format date for display
  const formatDate = (date: string | Date) => {
    return new Date(date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />
      
      <div className="py-10">
        <header>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-3xl font-bold leading-tight text-gray-900">Customer Dashboard</h1>
          </div>
        </header>
        
        <main>
          <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
            {/* Overview Section */}
            <div className="px-4 py-6 sm:px-0">
              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {/* Active Subscriptions Card */}
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 bg-primary rounded-md p-3">
                        <CreditCard className="h-6 w-6 text-white" />
                      </div>
                      <div className="ml-5 w-0 flex-1">
                        <dl>
                          <dt className="text-sm font-medium text-gray-500 truncate">
                            Active Subscriptions
                          </dt>
                          <dd>
                            {subscriptionsLoading ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <div className="text-lg font-medium text-gray-900">
                                {subscriptions?.length || 0}
                              </div>
                            )}
                          </dd>
                        </dl>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="bg-gray-50 px-6 py-3">
                    <div className="text-sm">
                      <a href="#subscriptions" className="font-medium text-primary hover:text-blue-500">
                        View all
                      </a>
                    </div>
                  </CardFooter>
                </Card>

                {/* Open Tickets Card */}
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 bg-accent rounded-md p-3">
                        <MessageSquare className="h-6 w-6 text-white" />
                      </div>
                      <div className="ml-5 w-0 flex-1">
                        <dl>
                          <dt className="text-sm font-medium text-gray-500 truncate">
                            Open Support Tickets
                          </dt>
                          <dd>
                            {ticketsLoading ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <div className="text-lg font-medium text-gray-900">
                                {tickets?.filter(t => t.status !== "Resolved").length || 0}
                              </div>
                            )}
                          </dd>
                        </dl>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="bg-gray-50 px-6 py-3">
                    <div className="text-sm">
                      <a href="#tickets" className="font-medium text-primary hover:text-blue-500">
                        View all
                      </a>
                    </div>
                  </CardFooter>
                </Card>

                {/* Documentation Card */}
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 bg-secondary rounded-md p-3">
                        <FileText className="h-6 w-6 text-white" />
                      </div>
                      <div className="ml-5 w-0 flex-1">
                        <dl>
                          <dt className="text-sm font-medium text-gray-500 truncate">
                            Documentation
                          </dt>
                          <dd>
                            <div className="text-lg font-medium text-gray-900">5 Guides</div>
                          </dd>
                        </dl>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="bg-gray-50 px-6 py-3">
                    <div className="text-sm">
                      <a href="#" className="font-medium text-primary hover:text-blue-500">
                        View all
                      </a>
                    </div>
                  </CardFooter>
                </Card>
              </div>
            </div>

            {/* Subscriptions Section */}
            <div className="px-4 py-6 sm:px-0" id="subscriptions">
              <h2 className="text-lg font-medium text-gray-900">Your Subscriptions</h2>
              <div className="mt-4 bg-white shadow overflow-hidden sm:rounded-md">
                {subscriptionsLoading ? (
                  <div className="p-6 flex justify-center">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : subscriptionsError ? (
                  <div className="p-6 text-center text-red-500">
                    Error loading subscriptions: {subscriptionsError.message}
                  </div>
                ) : subscriptions?.length === 0 ? (
                  <div className="p-6 text-center text-gray-500">
                    You don't have any active subscriptions.
                  </div>
                ) : (
                  <ul className="divide-y divide-gray-200">
                    {subscriptions?.map((subscription) => (
                      <li key={subscription.id}>
                        <div className="px-4 py-4 sm:px-6">
                          <div className="flex items-center justify-between">
                            <p className="text-sm font-medium text-primary truncate">
                              {subscription.name}
                            </p>
                            <div className="ml-2 flex-shrink-0 flex">
                              <p className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                {subscription.status}
                              </p>
                            </div>
                          </div>
                          <div className="mt-2 sm:flex sm:justify-between">
                            <div className="sm:flex">
                              <p className="flex items-center text-sm text-gray-500">
                                {subscription.name === "Enterprise Plan" ? (
                                  <>
                                    <Users className="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" />
                                    50 Users
                                  </>
                                ) : (
                                  <>
                                    <Server className="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" />
                                    2TB Storage
                                  </>
                                )}
                              </p>
                              {subscription.name === "Enterprise Plan" && (
                                <p className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0 sm:ml-6">
                                  <svg className="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                    <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                                  </svg>
                                  Premium Support
                                </p>
                              )}
                            </div>
                            <div className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
                              <Calendar className="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" />
                              <p>
                                Renews on <time dateTime={subscription.expiresAt?.toString() || ""}>
                                  {subscription.expiresAt ? formatDate(subscription.expiresAt) : "N/A"}
                                </time>
                              </p>
                            </div>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>

            {/* Recent Tickets Section */}
            <div className="px-4 py-6 sm:px-0" id="tickets">
              <h2 className="text-lg font-medium text-gray-900">Recent Support Tickets</h2>
              <div className="mt-4 bg-white shadow overflow-hidden sm:rounded-md">
                {ticketsLoading ? (
                  <div className="p-6 flex justify-center">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : ticketsError ? (
                  <div className="p-6 text-center text-red-500">
                    Error loading tickets: {ticketsError.message}
                  </div>
                ) : tickets?.length === 0 ? (
                  <div className="p-6 text-center text-gray-500">
                    You don't have any support tickets.
                  </div>
                ) : (
                  <ul className="divide-y divide-gray-200">
                    {tickets?.map((ticket) => (
                      <li key={ticket.id}>
                        <a href="#" className="block hover:bg-gray-50">
                          <div className="px-4 py-4 sm:px-6">
                            <div className="flex items-center justify-between">
                              <p className="text-sm font-medium text-primary truncate">
                                {ticket.title}
                              </p>
                              <div className="ml-2 flex-shrink-0 flex">
                                <p className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                  ticket.status === "Open" ? "bg-blue-100 text-blue-800" :
                                  ticket.status === "In Progress" ? "bg-yellow-100 text-yellow-800" :
                                  "bg-green-100 text-green-800"
                                }`}>
                                  {ticket.status}
                                </p>
                              </div>
                            </div>
                            <div className="mt-2 sm:flex sm:justify-between">
                              <div className="sm:flex">
                                <p className="flex items-center text-sm text-gray-500">
                                  <svg className="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                                  </svg>
                                  Ticket #{ticket.ticketNumber}
                                </p>
                              </div>
                              <div className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
                                <Calendar className="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" />
                                <p>
                                  Created on <time dateTime={ticket.createdAt?.toString() || ""}>
                                    {ticket.createdAt ? formatDate(ticket.createdAt) : "N/A"}
                                  </time>
                                </p>
                              </div>
                            </div>
                          </div>
                        </a>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
              <div className="mt-4 flex justify-end">
                <Button>Create New Ticket</Button>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
