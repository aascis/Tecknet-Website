import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Redirect } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { UserRole } from "@shared/schema";
import { Loader2 } from "lucide-react";
import Navbar from "@/components/Navbar";

// Customer login schema
const customerLoginSchema = z.object({
  username: z.string().email("Please enter a valid email"),
  password: z.string().min(1, "Password is required"),
  role: z.literal(UserRole.CUSTOMER),
  rememberMe: z.boolean().optional(),
});

// Employee login schema
const employeeLoginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
  role: z.literal(UserRole.EMPLOYEE),
  rememberMe: z.boolean().optional(),
});

// Registration schema
const registrationSchema = z.object({
  username: z.string().email("Please enter a valid email"),
  password: z
    .string()
    .min(8, "Password must be at least 8 characters")
    .max(100),
  confirmPassword: z.string().min(1, "Please confirm your password"),
  fullName: z.string().min(1, "Full name is required"),
  role: z.literal(UserRole.CUSTOMER),
  agreeToTerms: z.literal(true, {
    errorMap: () => ({ message: "You must agree to the terms and conditions" }),
  }),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

type CustomerLoginFormValues = z.infer<typeof customerLoginSchema>;
type EmployeeLoginFormValues = z.infer<typeof employeeLoginSchema>;
type RegistrationFormValues = z.infer<typeof registrationSchema>;

export default function AuthPage() {
  const [activeTab, setActiveTab] = useState<"customer" | "employee" | "register">("customer");
  const { user, isLoading, loginMutation, registerMutation } = useAuth();

  // Customer login form
  const customerLoginForm = useForm<CustomerLoginFormValues>({
    resolver: zodResolver(customerLoginSchema),
    defaultValues: {
      username: "",
      password: "",
      role: UserRole.CUSTOMER,
      rememberMe: false,
    },
  });

  // Employee login form
  const employeeLoginForm = useForm<EmployeeLoginFormValues>({
    resolver: zodResolver(employeeLoginSchema),
    defaultValues: {
      username: "",
      password: "",
      role: UserRole.EMPLOYEE,
      rememberMe: false,
    },
  });

  // Registration form
  const registrationForm = useForm<RegistrationFormValues>({
    resolver: zodResolver(registrationSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
      fullName: "",
      role: UserRole.CUSTOMER,
      agreeToTerms: false,
    },
  });

  // Handle customer login
  const onCustomerLoginSubmit = (data: CustomerLoginFormValues) => {
    loginMutation.mutate({
      username: data.username,
      password: data.password,
      role: data.role,
    });
  };

  // Handle employee login
  const onEmployeeLoginSubmit = (data: EmployeeLoginFormValues) => {
    loginMutation.mutate({
      username: data.username,
      password: data.password,
      role: data.role,
    });
  };

  // Handle registration
  const onRegisterSubmit = (data: RegistrationFormValues) => {
    const { confirmPassword, agreeToTerms, ...registerData } = data;
    registerMutation.mutate(registerData);
  };

  // Redirect if user is already logged in
  if (user) {
    return (
      <Redirect
        to={user.role === UserRole.CUSTOMER ? "/customer-dashboard" : "/employee-dashboard"}
      />
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />
      
      <div className="flex-grow flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl w-full space-y-8 flex">
          {/* Auth forms */}
          <div className="w-full md:w-1/2 bg-white p-8 rounded-lg shadow-md">
            <div className="text-center">
              <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
                Welcome to CloudService
              </h2>
              <p className="mt-2 text-center text-sm text-gray-600">
                Please sign in to your account or create a new one
              </p>
            </div>

            <Tabs
              defaultValue="customer"
              value={activeTab}
              onValueChange={(value) => setActiveTab(value as any)}
              className="mt-8"
            >
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="customer">Customer Login</TabsTrigger>
                <TabsTrigger value="employee">Employee Login</TabsTrigger>
                <TabsTrigger value="register">Register</TabsTrigger>
              </TabsList>

              {/* Customer Login Form */}
              <TabsContent value="customer">
                <Form {...customerLoginForm}>
                  <form
                    onSubmit={customerLoginForm.handleSubmit(onCustomerLoginSubmit)}
                    className="space-y-6 mt-4"
                  >
                    <FormField
                      control={customerLoginForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email address</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              type="email"
                              placeholder="customer@example.com"
                              autoComplete="email"
                              disabled={loginMutation.isPending}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={customerLoginForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              type="password"
                              placeholder="••••••••"
                              autoComplete="current-password"
                              disabled={loginMutation.isPending}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="flex items-center justify-between">
                      <FormField
                        control={customerLoginForm.control}
                        name="rememberMe"
                        render={({ field }) => (
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="customer-remember-me"
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              disabled={loginMutation.isPending}
                            />
                            <label
                              htmlFor="customer-remember-me"
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              Remember me
                            </label>
                          </div>
                        )}
                      />

                      <div className="text-sm">
                        <a href="#" className="font-medium text-primary hover:text-blue-500">
                          Forgot your password?
                        </a>
                      </div>
                    </div>

                    <Button
                      type="submit"
                      className="w-full"
                      disabled={loginMutation.isPending}
                    >
                      {loginMutation.isPending ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : null}
                      Sign in
                    </Button>
                  </form>
                </Form>
              </TabsContent>

              {/* Employee Login Form */}
              <TabsContent value="employee">
                <Form {...employeeLoginForm}>
                  <form
                    onSubmit={employeeLoginForm.handleSubmit(onEmployeeLoginSubmit)}
                    className="space-y-6 mt-4"
                  >
                    <FormField
                      control={employeeLoginForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Domain username</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              placeholder="john.doe"
                              autoComplete="username"
                              disabled={loginMutation.isPending}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={employeeLoginForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              type="password"
                              placeholder="••••••••"
                              autoComplete="current-password"
                              disabled={loginMutation.isPending}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="flex items-center">
                      <FormField
                        control={employeeLoginForm.control}
                        name="rememberMe"
                        render={({ field }) => (
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="employee-remember-me"
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              disabled={loginMutation.isPending}
                            />
                            <label
                              htmlFor="employee-remember-me"
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              Remember me
                            </label>
                          </div>
                        )}
                      />
                    </div>

                    <Button
                      type="submit"
                      className="w-full"
                      disabled={loginMutation.isPending}
                    >
                      {loginMutation.isPending ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : null}
                      Sign in
                    </Button>
                  </form>
                </Form>
              </TabsContent>

              {/* Registration Form */}
              <TabsContent value="register">
                <Form {...registrationForm}>
                  <form
                    onSubmit={registrationForm.handleSubmit(onRegisterSubmit)}
                    className="space-y-6 mt-4"
                  >
                    <FormField
                      control={registrationForm.control}
                      name="fullName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              placeholder="John Doe"
                              disabled={registerMutation.isPending}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={registrationForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email address</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              type="email"
                              placeholder="john.doe@example.com"
                              autoComplete="email"
                              disabled={registerMutation.isPending}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={registrationForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              type="password"
                              placeholder="••••••••"
                              autoComplete="new-password"
                              disabled={registerMutation.isPending}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={registrationForm.control}
                      name="confirmPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Confirm Password</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              type="password"
                              placeholder="••••••••"
                              autoComplete="new-password"
                              disabled={registerMutation.isPending}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={registrationForm.control}
                      name="agreeToTerms"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              disabled={registerMutation.isPending}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>
                              I agree to the{" "}
                              <a href="#" className="text-primary hover:underline">
                                terms and conditions
                              </a>
                            </FormLabel>
                            <FormMessage />
                          </div>
                        </FormItem>
                      )}
                    />

                    <Button
                      type="submit"
                      className="w-full"
                      disabled={registerMutation.isPending}
                    >
                      {registerMutation.isPending ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : null}
                      Create account
                    </Button>
                  </form>
                </Form>
              </TabsContent>
            </Tabs>
          </div>

          {/* Hero Section */}
          <div className="hidden md:block md:w-1/2 bg-primary rounded-r-lg p-8 text-white">
            <div className="h-full flex flex-col justify-center">
              <h3 className="text-2xl font-bold mb-4">Welcome to CloudService</h3>
              <p className="mb-6">
                Our platform provides all the tools your business needs to streamline operations and boost productivity.
              </p>
              <ul className="space-y-4">
                <li className="flex items-center">
                  <svg className="h-5 w-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                  </svg>
                  Role-based access control for teams
                </li>
                <li className="flex items-center">
                  <svg className="h-5 w-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                  </svg>
                  Integrated support ticket system
                </li>
                <li className="flex items-center">
                  <svg className="h-5 w-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                  </svg>
                  Comprehensive documentation
                </li>
                <li className="flex items-center">
                  <svg className="h-5 w-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                  </svg>
                  Secure authentication systems
                </li>
              </ul>
              <div className="mt-8">
                <p className="text-sm">
                  Already have an account? Sign in to access your dashboard.
                </p>
                <p className="text-sm mt-2">
                  New to CloudService? Create an account to get started with our services.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
