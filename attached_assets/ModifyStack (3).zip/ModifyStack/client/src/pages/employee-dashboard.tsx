import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Application } from "@shared/schema";
import { Loader2 } from "lucide-react";
import * as LucideIcons from "lucide-react";
import Navbar from "@/components/Navbar";
import { Badge } from "@/components/ui/badge";

export default function EmployeeDashboard() {
  const { user } = useAuth();

  // Fetch applications for employee dashboard
  const {
    data: applications,
    isLoading: applicationsLoading,
    error: applicationsError,
  } = useQuery<Application[]>({
    queryKey: ["/api/applications"],
    enabled: !!user,
  });

  // Dynamic icon component from iconClass
  const renderIcon = (iconClass: string) => {
    const Icon = LucideIcons[iconClass as keyof typeof LucideIcons] || LucideIcons.AppWindow;
    return <Icon className="h-6 w-6 text-white" />;
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Nav bar with dark theme for employee dashboard */}
      <nav className="bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <span className="text-white font-bold text-xl">CloudService</span>
              </div>
              <div className="hidden md:block">
                <div className="ml-10 flex items-baseline space-x-4">
                  <a href="#" className="bg-gray-900 text-white px-3 py-2 rounded-md text-sm font-medium" aria-current="page">Dashboard</a>
                  <a href="#applications" className="text-gray-300 hover:bg-gray-700 hover:text-white px-3 py-2 rounded-md text-sm font-medium">Applications</a>
                  <a href="#" className="text-gray-300 hover:bg-gray-700 hover:text-white px-3 py-2 rounded-md text-sm font-medium">Documentation</a>
                  <a href="#" className="text-gray-300 hover:bg-gray-700 hover:text-white px-3 py-2 rounded-md text-sm font-medium">Support</a>
                </div>
              </div>
            </div>
            <div className="hidden md:block">
              <div className="ml-4 flex items-center md:ml-6">
                {/* Profile dropdown */}
                <div className="ml-3 relative">
                  <div className="flex items-center">
                    <div className="inline-flex items-center justify-center h-8 w-8 rounded-full bg-gray-500">
                      <span className="text-sm font-medium leading-none text-white">
                        {user?.fullName?.substring(0, 2) || user?.username.substring(0, 2)}
                      </span>
                    </div>
                    <span className="ml-2 text-white">{user?.fullName || user?.username}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold text-gray-900">Employee Dashboard</h1>
            <Badge variant="secondary" className="text-xs px-3 py-1">
              Welcome, {user?.fullName || user?.username}
            </Badge>
          </div>
        </div>
      </header>
      
      <main>
        <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
          {/* Application Links Section */}
          <div className="px-4 sm:px-0" id="applications">
            <h2 className="text-lg font-medium text-gray-900">Company Applications</h2>
            
            {applicationsLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-12 w-12 animate-spin text-primary" />
              </div>
            ) : applicationsError ? (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mt-4">
                Error loading applications: {applicationsError.message}
              </div>
            ) : (
              <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {applications?.map((app) => (
                  <div key={app.id} className="bg-white overflow-hidden shadow rounded-lg">
                    <div className="p-5">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 p-3 rounded-md" style={{ backgroundColor: app.iconBgColor || '#3B82F6' }}>
                          {renderIcon(app.iconClass)}
                        </div>
                        <div className="ml-5">
                          <h3 className="text-lg font-medium text-gray-900">{app.name}</h3>
                          <p className="text-sm text-gray-500">{app.description}</p>
                        </div>
                      </div>
                    </div>
                    <div className="bg-gray-50 px-5 py-3">
                      <a 
                        href={app.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-sm font-medium text-primary hover:text-blue-500"
                      >
                        Launch application &rarr;
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Documentation Section */}
          <div className="px-4 sm:px-0 mt-8">
            <h2 className="text-lg font-medium text-gray-900">Documentation</h2>
            <div className="mt-4 bg-white shadow overflow-hidden sm:rounded-lg">
              <div className="px-4 py-5 sm:p-6">
                <h3 className="text-lg leading-6 font-medium text-gray-900">
                  Access Company Resources
                </h3>
                <div className="mt-2 max-w-xl text-sm text-gray-500">
                  <p>
                    All company documentation is available through our secure documentation portal.
                    Click the button below to access guides, policies, and product information.
                  </p>
                </div>
                <div className="mt-5">
                  <a
                    href="https://docs.example.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                  >
                    View Documentation
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Support Section */}
          <div className="px-4 sm:px-0 mt-8">
            <h2 className="text-lg font-medium text-gray-900">Support</h2>
            <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="bg-white shadow overflow-hidden sm:rounded-lg">
                <div className="px-4 py-5 sm:p-6">
                  <h3 className="text-lg leading-6 font-medium text-gray-900">
                    IT Support
                  </h3>
                  <div className="mt-2 max-w-xl text-sm text-gray-500">
                    <p>For hardware, software, or network issues, contact the IT department.</p>
                  </div>
                  <div className="mt-5">
                    <a
                      href="mailto:it-support@example.com"
                      className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                    >
                      Email IT Support
                    </a>
                  </div>
                </div>
              </div>

              <div className="bg-white shadow overflow-hidden sm:rounded-lg">
                <div className="px-4 py-5 sm:p-6">
                  <h3 className="text-lg leading-6 font-medium text-gray-900">
                    Help Desk
                  </h3>
                  <div className="mt-2 max-w-xl text-sm text-gray-500">
                    <p>For application-specific issues or questions, submit a ticket to the help desk.</p>
                  </div>
                  <div className="mt-5">
                    <a
                      href="https://support.example.com"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                    >
                      Submit Ticket
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
