import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import { useState } from "react";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();

  const navLinks = [
    { name: "Home", href: "/" },
    { name: "Features", href: "/#features" },
    { name: "Pricing", href: "/#pricing" },
    { name: "Contact", href: "/contact" },
  ];

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  // Determine which dashboard link to show based on user role
  const getDashboardLink = () => {
    if (!user) return "/";
    return user.role === "customer" 
      ? "/customer-dashboard" 
      : "/employee-dashboard";
  };

  return (
    <nav className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <Link href="/">
                <span className="text-primary font-bold text-xl cursor-pointer">CloudService</span>
              </Link>
            </div>
            <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
              {navLinks.map(link => (
                <div key={link.href} className="inline-block">
                  <Link href={link.href}>
                    <span
                      className={`${
                        location === link.href
                          ? "border-primary text-gray-900"
                          : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
                      } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium cursor-pointer`}
                    >
                      {link.name}
                    </span>
                  </Link>
                </div>
              ))}
            </div>
          </div>
          <div className="hidden sm:ml-6 sm:flex sm:items-center">
            <div className="flex space-x-4">
              {user ? (
                <>
                  <Button variant="outline" asChild>
                    <Link href={getDashboardLink()}>Dashboard</Link>
                  </Button>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="flex items-center gap-2">
                        <div className="flex items-center justify-center h-8 w-8 rounded-full bg-gray-500">
                          <span className="text-sm font-medium leading-none text-white">
                            {user.fullName?.substring(0, 2) || user.username.substring(0, 2)}
                          </span>
                        </div>
                        <span className="hidden md:inline">{user.fullName || user.username}</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>Profile</DropdownMenuItem>
                      <DropdownMenuItem>Settings</DropdownMenuItem>
                      <DropdownMenuItem onClick={handleLogout}>Logout</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </>
              ) : (
                <>
                  <Button variant="outline" asChild>
                    <Link href="/auth">Log in</Link>
                  </Button>
                  <Button asChild>
                    <Link href="/auth">Sign up</Link>
                  </Button>
                </>
              )}
            </div>
          </div>
          <div className="-mr-2 flex items-center sm:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsOpen(!isOpen)}
              aria-expanded={isOpen}
              aria-label="Toggle navigation menu"
            >
              <span className="sr-only">Open main menu</span>
              {isOpen ? (
                <X className="block h-6 w-6" />
              ) : (
                <Menu className="block h-6 w-6" />
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="sm:hidden">
          <div className="pt-2 pb-3 space-y-1">
            {navLinks.map(link => (
              <div key={link.href}>
                <Link href={link.href}>
                  <span
                    className={`${
                      location === link.href
                        ? "bg-primary border-primary text-white"
                        : "border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800"
                    } block pl-3 pr-4 py-2 border-l-4 text-base font-medium cursor-pointer`}
                    onClick={() => setIsOpen(false)}
                  >
                    {link.name}
                  </span>
                </Link>
              </div>
            ))}
          </div>
          <div className="pt-4 pb-3 border-t border-gray-200">
            <div className="flex items-center px-4 space-x-3">
              {user ? (
                <>
                  <Link href={getDashboardLink()}>
                    <span 
                      className="block px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 cursor-pointer"
                      onClick={() => setIsOpen(false)}
                    >
                      Dashboard
                    </span>
                  </Link>
                  <Button 
                    variant="destructive" 
                    onClick={() => {
                      handleLogout();
                      setIsOpen(false);
                    }}
                  >
                    Logout
                  </Button>
                </>
              ) : (
                <>
                  <Link href="/auth">
                    <span 
                      className="block px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 cursor-pointer"
                      onClick={() => setIsOpen(false)}
                    >
                      Log in
                    </span>
                  </Link>
                  <Link href="/auth">
                    <span 
                      className="block px-4 py-2 text-base font-medium text-white bg-primary rounded-md hover:bg-blue-600 cursor-pointer"
                      onClick={() => setIsOpen(false)}
                    >
                      Sign up
                    </span>
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
