# Quick Fix for 405 Not Allowed Error

This problem occurs because Nginx is blocking the HTTP POST method needed for authentication. Follow these steps to fix it:

## Fix for Nginx

1. Edit your Nginx site configuration file (typically in `/etc/nginx/sites-available/` or `/etc/nginx/conf.d/`):

```bash
sudo nano /etc/nginx/sites-available/your-site
```

2. Find the `location /` block and add the `proxy_method` directive:

```nginx
location / {
    proxy_pass http://172.24.57.70:8084;  # Your specific server IP and port
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_cache_bypass $http_upgrade;
    
    # Add this line to fix the 405 error
    proxy_method $request_method;
}
```

3. Test the configuration:

```bash
sudo nginx -t
```

4. If the test passes, reload Nginx:

```bash
sudo systemctl reload nginx
```

5. Try logging in again with your AD credentials. It should work now!

## Alternative Fix

If the above doesn't work, you can try this more permissive approach:

```nginx
location / {
    # Other proxy settings...
    
    # Add these lines to fix the 405 error
    proxy_pass_request_headers on;
    proxy_pass_request_body on;
    
    # Explicitly allow all methods
    if ($request_method = POST) {
        proxy_pass http://172.24.57.70:8084;
    }
    if ($request_method = GET) {
        proxy_pass http://172.24.57.70:8084;
    }
    if ($request_method = PUT) {
        proxy_pass http://172.24.57.70:8084;
    }
    if ($request_method = DELETE) {
        proxy_pass http://172.24.57.70:8084;
    }
}
```

After making either of these changes, remember to test and reload Nginx.