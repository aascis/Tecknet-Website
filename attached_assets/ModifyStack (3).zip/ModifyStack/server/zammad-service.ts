import axios from 'axios';
import { ContactFormData } from '@shared/schema';

interface ZammadTicket {
  title: string;
  group: string;
  customer_id: string | null;
  article: {
    subject: string;
    body: string;
    type: string;
    internal: boolean;
    content_type: string;
  };
}

export class ZammadService {
  private baseUrl: string;
  private apiToken: string;
  private defaultGroup: string;

  constructor() {
    this.baseUrl = process.env.ZAMMAD_API_URL || '';
    this.apiToken = process.env.ZAMMAD_API_TOKEN || '';
    this.defaultGroup = process.env.ZAMMAD_DEFAULT_GROUP || 'Sales';
  }

  /**
   * Create a ticket in Zammad from contact form submission
   */
  async createTicketFromContactForm(contactFormData: ContactFormData): Promise<{ success: boolean; ticketId?: string; error?: string }> {
    try {
      if (!this.baseUrl || !this.apiToken) {
        console.error('Zammad API URL or Token not configured.');
        return { success: false, error: 'Zammad API not configured' };
      }

      // First, lookup or create customer
      const customerResponse = await this.findOrCreateCustomer(contactFormData);
      if (!customerResponse.success) {
        return { success: false, error: customerResponse.error };
      }

      // Format ticket data
      const ticket: ZammadTicket = {
        title: `Contact Request: ${contactFormData.subject}`,
        group: this.defaultGroup,
        customer_id: customerResponse.customerId || null,
        article: {
          subject: contactFormData.subject,
          body: this.formatTicketBody(contactFormData),
          type: 'note',
          internal: false,
          content_type: 'text/html',
        },
      };

      // Create ticket in Zammad - ensure proper API endpoint
      const endpoint = this.baseUrl.endsWith('/api/v1') 
        ? `${this.baseUrl}/tickets` 
        : `${this.baseUrl}/api/v1/tickets`;
        
      const response = await axios.post(endpoint, ticket, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Token token=${this.apiToken}`,
        },
      });

      if (response.status === 201) {
        return { success: true, ticketId: response.data.id };
      } else {
        return { success: false, error: 'Failed to create ticket' };
      }
    } catch (error: any) {
      console.error('Error creating Zammad ticket:', error);
      return { 
        success: false, 
        error: error.response?.data?.error || error.message || 'Unknown error' 
      };
    }
  }

  /**
   * Find or create a customer in Zammad
   */
  private async findOrCreateCustomer(contactData: ContactFormData): Promise<{ success: boolean; customerId?: string; error?: string }> {
    try {
      // First, search for customer by email - ensure proper API endpoint
      const userEndpoint = this.baseUrl.endsWith('/api/v1') 
        ? `${this.baseUrl}/users/search` 
        : `${this.baseUrl}/api/v1/users/search`;
      
      const searchResponse = await axios.get(`${userEndpoint}?query=${encodeURIComponent(contactData.email)}`, {
        headers: {
          'Authorization': `Token token=${this.apiToken}`,
        },
      });

      // If customer exists, return the ID
      if (searchResponse.data && searchResponse.data.length > 0) {
        return { success: true, customerId: searchResponse.data[0].id };
      }

      // Otherwise, create new customer
      const newCustomer = {
        firstname: contactData.firstName,
        lastname: contactData.lastName,
        email: contactData.email,
        phone: contactData.phone || '',
        organization: contactData.company || '',
      };

      // Create user endpoint
      const createUserEndpoint = this.baseUrl.endsWith('/api/v1') 
        ? `${this.baseUrl}/users` 
        : `${this.baseUrl}/api/v1/users`;
      
      const createResponse = await axios.post(createUserEndpoint, newCustomer, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Token token=${this.apiToken}`,
        },
      });

      if (createResponse.status === 201) {
        return { success: true, customerId: createResponse.data.id };
      } else {
        return { success: false, error: 'Failed to create customer' };
      }
    } catch (error: any) {
      console.error('Error finding/creating Zammad customer:', error);
      return { 
        success: false, 
        error: error.response?.data?.error || error.message || 'Unknown error' 
      };
    }
  }

  /**
   * Format the contact form data into a nice HTML body for the ticket
   */
  private formatTicketBody(data: ContactFormData): string {
    // Combine first and last name for display
    const fullName = `${data.firstName} ${data.lastName}`.trim();
    
    return `
      <h2>New Contact Form Submission</h2>
      <table border="0" cellpadding="5" cellspacing="0" style="width: 100%;">
        <tr>
          <td style="width: 120px;"><strong>Name:</strong></td>
          <td>${fullName}</td>
        </tr>
        <tr>
          <td><strong>Email:</strong></td>
          <td>${data.email}</td>
        </tr>
        ${data.phone ? `
        <tr>
          <td><strong>Phone:</strong></td>
          <td>${data.phone}</td>
        </tr>` : ''}
        ${data.company ? `
        <tr>
          <td><strong>Company:</strong></td>
          <td>${data.company}</td>
        </tr>` : ''}
        <tr>
          <td><strong>Subject:</strong></td>
          <td>${data.subject}</td>
        </tr>
        <tr>
          <td valign="top"><strong>Message:</strong></td>
          <td>${data.message.replace(/\n/g, '<br>')}</td>
        </tr>
      </table>
    `;
  }
}

// Create a singleton instance
export const zammadService = new ZammadService();