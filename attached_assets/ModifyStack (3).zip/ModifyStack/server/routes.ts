import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { contactFormSchema } from "@shared/schema";
import axios from "axios";
import { zammadService } from "./zammad-service";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // Seed initial data if needed
  await seedInitialData();

  // Contact form submission with Zammad integration
  app.post("/api/contact", async (req, res) => {
    try {
      // Validate form data
      const validatedData = contactFormSchema.parse(req.body);
      
      // In production, create a ticket in Zammad
      if (process.env.NODE_ENV === 'production' && process.env.ZAMMAD_API_URL) {
        const result = await zammadService.createTicketFromContactForm(validatedData);
        
        if (result.success) {
          // Also store the ticket in our own database for reference
          const ticket = await storage.createTicket({
            userId: 0, // System ticket (no user)
            title: validatedData.subject,
            description: validatedData.message,
            status: "New",
            ticketNumber: `Z-${result.ticketId || Date.now().toString().slice(-6)}`
          });
          
          return res.status(201).json({ 
            message: 'Ticket created successfully',
            ticketId: result.ticketId,
            reference: ticket.ticketNumber
          });
        } else {
          // If Zammad integration fails, log the error but don't reject the submission
          console.error('Zammad integration error:', result.error);
          // Still create a ticket in our system
          const ticket = await storage.createTicket({
            userId: 0, // System ticket (no user)
            title: validatedData.subject,
            description: validatedData.message,
            status: "New",
            ticketNumber: `C-${Date.now().toString().slice(-6)}`
          });
          
          return res.status(201).json({ 
            message: 'Contact form submitted successfully, but ticket creation had an issue',
            reference: ticket.ticketNumber
          });
        }
      } else {
        // In development, just create a ticket in our database
        const ticket = await storage.createTicket({
          userId: 0, // System ticket (no user)
          title: validatedData.subject,
          description: validatedData.message,
          status: "New",
          ticketNumber: `DEV-${Date.now().toString().slice(-6)}`
        });
        
        return res.status(201).json({ 
          message: 'Ticket created successfully (Development Mode)',
          reference: ticket.ticketNumber
        });
      }
    } catch (error: any) {
      console.error('Contact form submission error:', error);
      return res.status(400).json({ message: 'Invalid form data', error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Seed initial data for testing
async function seedInitialData() {
  // Check if applications exist
  const apps = await storage.getAllApplications();
  if (apps.length === 0) {
    // Seed applications for employee dashboard
    const demoApps = [
      {
        name: "Sales Dashboard",
        description: "View and analyze sales data",
        url: "https://sales.example.com",
        iconClass: "bar-chart",
        iconBgColor: "#3B82F6" // primary color
      },
      {
        name: "Customer Support",
        description: "Manage customer issues",
        url: "https://support.example.com",
        iconClass: "message-square",
        iconBgColor: "#8B5CF6" // accent color
      },
      {
        name: "HR Portal",
        description: "Employee management system",
        url: "https://hr.example.com",
        iconClass: "users",
        iconBgColor: "#10B981" // secondary color
      },
      {
        name: "Calendar",
        description: "Company events and scheduling",
        url: "https://calendar.example.com",
        iconClass: "calendar",
        iconBgColor: "#EF4444" // red color
      },
      {
        name: "Documentation",
        description: "Product and system guides",
        url: "https://docs.example.com",
        iconClass: "file-text",
        iconBgColor: "#F59E0B" // yellow color
      },
      {
        name: "Finance Portal",
        description: "Expense and financial management",
        url: "https://finance.example.com",
        iconClass: "credit-card",
        iconBgColor: "#10B981" // green color
      }
    ];

    for (const app of demoApps) {
      await storage.createApplication(app);
    }
  }

  // Create demo customer account if not exists
  const customerUser = await storage.getUserByUsername('customer@example.com');
  if (!customerUser) {
    // Import the hashPassword function directly
    const { hashPassword } = await import('./auth');
    await storage.createUser({
      username: 'customer@example.com',
      password: await hashPassword('customer123'),
      email: 'customer@example.com',
      fullName: 'John Doe',
      role: 'customer'
    });
  }

  // Create demo subscriptions if none exist
  const customer = await storage.getUserByUsername('customer@example.com');
  if (customer) {
    const subs = await storage.getSubscriptionsByUserId(customer.id);
    if (subs.length === 0) {
      // Sample subscriptions
      const demoSubscriptions = [
        {
          userId: customer.id,
          name: "Enterprise Plan",
          description: "Full access to all platform features with premium support",
          status: "Active",
          expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 365) // 1 year
        },
        {
          userId: customer.id,
          name: "Cloud Storage Add-on",
          description: "2TB of secure cloud storage",
          status: "Active",
          expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 180) // 180 days
        }
      ];

      for (const sub of demoSubscriptions) {
        await storage.createSubscription(sub);
      }
    }

    // Create demo tickets if none exist
    const tickets = await storage.getTicketsByUserId(customer.id);
    if (tickets.length === 0) {
      // Sample tickets
      const demoTickets = [
        {
          userId: customer.id,
          title: "API Integration Issue",
          description: "I'm having trouble connecting to the API using the provided credentials.",
          status: "In Progress",
          ticketNumber: "T-58291"
        },
        {
          userId: customer.id,
          title: "Account Access Problem",
          description: "I can't access my account from my work computer.",
          status: "Resolved",
          ticketNumber: "T-58290"
        }
      ];

      for (const ticket of demoTickets) {
        await storage.createTicket(ticket);
      }
    }
  }
}
