import { 
  users, type User, type InsertUser,
  subscriptions, type Subscription, type InsertSubscription,
  tickets, type Ticket, type InsertTicket,
  applications, type Application, type InsertApplication
} from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";

// Initialize memory store for sessions
const MemoryStore = createMemoryStore(session);

// Storage interface
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Subscription operations
  getSubscriptionsByUserId(userId: number): Promise<Subscription[]>;
  createSubscription(subscription: InsertSubscription): Promise<Subscription>;
  
  // Ticket operations
  getTicketsByUserId(userId: number): Promise<Ticket[]>;
  createTicket(ticket: InsertTicket): Promise<Ticket>;
  
  // Application operations
  getAllApplications(): Promise<Application[]>;
  createApplication(application: InsertApplication): Promise<Application>;
  
  // Session store
  sessionStore: any; // Using any for sessionStore to avoid type conflicts
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private subscriptions: Map<number, Subscription>;
  private tickets: Map<number, Ticket>;
  private applications: Map<number, Application>;
  sessionStore: any; // Using any for sessionStore to avoid type conflicts
  currentUserId: number;
  currentSubscriptionId: number;
  currentTicketId: number;
  currentApplicationId: number;

  constructor() {
    this.users = new Map();
    this.subscriptions = new Map();
    this.tickets = new Map();
    this.applications = new Map();
    this.currentUserId = 1;
    this.currentSubscriptionId = 1;
    this.currentTicketId = 1;
    this.currentApplicationId = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: now,
      email: insertUser.email || null,
      fullName: insertUser.fullName || null
    };
    this.users.set(id, user);
    return user;
  }

  // Subscription operations
  async getSubscriptionsByUserId(userId: number): Promise<Subscription[]> {
    return Array.from(this.subscriptions.values()).filter(
      (subscription) => subscription.userId === userId
    );
  }

  async createSubscription(insertSubscription: InsertSubscription): Promise<Subscription> {
    const id = this.currentSubscriptionId++;
    const now = new Date();
    const subscription: Subscription = { 
      ...insertSubscription, 
      id, 
      createdAt: now,
      description: insertSubscription.description || null,
      expiresAt: insertSubscription.expiresAt || null
    };
    this.subscriptions.set(id, subscription);
    return subscription;
  }

  // Ticket operations
  async getTicketsByUserId(userId: number): Promise<Ticket[]> {
    return Array.from(this.tickets.values()).filter(
      (ticket) => ticket.userId === userId
    );
  }

  async createTicket(insertTicket: InsertTicket): Promise<Ticket> {
    const id = this.currentTicketId++;
    const now = new Date();
    const ticket: Ticket = { ...insertTicket, id, createdAt: now };
    this.tickets.set(id, ticket);
    return ticket;
  }

  // Application operations
  async getAllApplications(): Promise<Application[]> {
    return Array.from(this.applications.values());
  }

  async createApplication(insertApplication: InsertApplication): Promise<Application> {
    const id = this.currentApplicationId++;
    const application: Application = { 
      ...insertApplication, 
      id,
      description: insertApplication.description || null,
      iconClass: insertApplication.iconClass || null,
      iconBgColor: insertApplication.iconBgColor || null
    };
    this.applications.set(id, application);
    return application;
  }
}

export const storage = new MemStorage();
