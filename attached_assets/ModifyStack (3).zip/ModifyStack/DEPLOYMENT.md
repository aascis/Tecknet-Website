# Deployment Guide for CloudService SaaS Platform

This document outlines the steps to deploy the CloudService SaaS platform to a production environment.

## System Requirements

- Node.js 18.x or later
- PostgreSQL 14.x or later
- Nginx or Apache web server
- SSL certificate for HTTPS
- A server with at least 2GB RAM and 1 CPU core

## Environment Setup

1. Clone the repository to your server:
   ```bash
   git clone <repository-url> /var/www/cloudservice
   cd /var/www/cloudservice
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a `.env` file in the root directory based on the `.env.example` file:
   ```bash
   cp .env.example .env
   ```

4. Update the `.env` file with your actual configuration values:
   - Database credentials
   - Session secret (generate a strong random value)
   - Active Directory connection details
   - Zammad API credentials
   - Set `NODE_ENV=production`

## Database Setup

1. Create a PostgreSQL database:
   ```bash
   createdb cloudservice
   ```

2. Run database migrations:
   ```bash
   npm run db:push
   ```

## Building for Production

1. Build the frontend and prepare the server:
   ```bash
   npm run build
   ```

## Web Server Configuration

### Nginx Configuration

Create a new Nginx site configuration file:

```nginx
server {
    listen 80;
    server_name your-domain.com;
    
    # Redirect HTTP to HTTPS
    location / {
        return 301 https://$host$request_uri;
    }
}

server {
    listen 443 ssl;
    server_name your-domain.com;
    
    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;
    
    # SSL configuration (recommended)
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;
    
    location / {
        proxy_pass http://172.24.57.70:8084;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        # Important: Allow all HTTP methods (GET, POST, PUT, DELETE, etc.)
        # This fixes the 405 Not Allowed error
        proxy_method $request_method;
    }
}
```

### Apache Configuration

Create a new Apache site configuration file:

```apache
<VirtualHost *:80>
    ServerName your-domain.com
    Redirect permanent / https://your-domain.com/
</VirtualHost>

<VirtualHost *:443>
    ServerName your-domain.com
    
    SSLEngine on
    SSLCertificateFile /path/to/cert.pem
    SSLCertificateKeyFile /path/to/key.pem
    
    ProxyPreserveHost On
    ProxyPass / http://172.24.57.70:8084/
    ProxyPassReverse / http://172.24.57.70:8084/
    
    # These lines are important to ensure all HTTP methods work correctly
    <Proxy *>
        Order deny,allow
        Allow from all
    </Proxy>
    
    RequestHeader set X-Forwarded-Proto "https"
    RequestHeader set X-Forwarded-Port "443"
    
    ErrorLog ${APACHE_LOG_DIR}/cloudservice-error.log
    CustomLog ${APACHE_LOG_DIR}/cloudservice-access.log combined
</VirtualHost>
```

## Process Management with PM2

1. Install PM2 globally:
   ```bash
   npm install -g pm2
   ```

2. Create a PM2 process file called `ecosystem.config.js`:
   ```javascript
   module.exports = {
     apps: [
       {
         name: "cloudservice",
         script: "node dist/server/index.js",
         instances: "1",
         autorestart: true,
         watch: false,
         max_memory_restart: "1G",
         env: {
           NODE_ENV: "production"
         }
       }
     ]
   };
   ```

3. Start the application with PM2:
   ```bash
   pm2 start ecosystem.config.js
   ```

4. Set up PM2 to start on boot:
   ```bash
   pm2 startup
   pm2 save
   ```

## Active Directory Configuration

The application connects directly to your Windows Active Directory for employee authentication. Make sure:

1. The server has network access to the AD server (port 389 or 636 for LDAPS)
2. The AD connection details in the `.env` file are correct:
   - `AD_URL`: LDAP URL (e.g., ldap://172.24.8.100:389)
   - `AD_BASE_DN`: Base DN for searches (e.g., DC=tecknet,DC=ca)
   - `AD_USERNAME_SUFFIX`: Suffix to append to usernames (e.g., @tecknet.ca)
   - `AD_EMAIL_SUFFIX`: Email suffix for users (e.g., @tecknet.ca)

For secure connections, use LDAPS (LDAP over SSL) with the ldaps:// protocol.

## Zammad Integration

The application integrates with Zammad for ticket management. Ensure:

1. You have a working Zammad instance accessible from your server
2. The Zammad API credentials in the `.env` file are correct:
   - `ZAMMAD_API_URL`: The base URL of your Zammad API
   - `ZAMMAD_API_TOKEN`: A valid API token with permissions to create tickets and users
   - `ZAMMAD_DEFAULT_GROUP`: The name of the group to assign tickets to

## Backups

Set up regular backups for:

1. PostgreSQL database:
   ```bash
   pg_dump -U username -d cloudservice > backup_$(date +%Y%m%d).sql
   ```

2. Application files:
   ```bash
   tar -czf cloudservice_backup_$(date +%Y%m%d).tar.gz /var/www/cloudservice
   ```

Configure these commands as cron jobs for automated backups.

## Maintenance

- Regularly update the application with new releases
- Monitor logs with `pm2 logs cloudservice`
- Set up monitoring for the server and application uptime

## Troubleshooting

### General Troubleshooting
- Check application logs: `pm2 logs cloudservice`
- Check Nginx/Apache error logs
- Ensure all environment variables are correctly set
- Verify network connectivity to AD and Zammad services

### Fixing 405 Not Allowed Error with Nginx
If you see a "405 Not Allowed" error during employee login, it's usually because Nginx is not correctly proxying the HTTP methods (particularly POST requests):

1. Check your Nginx configuration and make sure it includes the following in the location block:
   ```nginx
   location / {
       proxy_pass http://172.24.57.70:8084;
       # ... other proxy settings ...
       
       # This line is critical for fixing 405 errors
       proxy_method $request_method;
   }
   ```

2. Test the configuration:
   ```bash
   sudo nginx -t
   ```

3. Reload Nginx:
   ```bash
   sudo systemctl reload nginx
   ```

4. Check Nginx error logs for more details:
   ```bash
   sudo tail -f /var/log/nginx/error.log
   ```

### Verifying Active Directory Connectivity
To verify your AD connection is working:

1. Test LDAP connectivity from your server:
   ```bash
   ldapsearch -x -H ldap://your-ad-server:389 -D "user@domain" -w password -b "DC=example,DC=com" "(sAMAccountName=username)"
   ```

2. Check firewall rules to ensure your server can reach the AD server on port 389 (or 636 for LDAPS)

3. Try different AD connection methods in the app if available

## Security Considerations

- Keep the server and all dependencies updated
- Use a firewall to restrict access to only necessary ports
- Set up fail2ban to protect against brute force attacks
- Consider implementing a Web Application Firewall (WAF)
- Use strong, unique passwords for all services
- Regularly audit access and permissions