// Test AD authentication directly
import ActiveDirectory from 'activedirectory2';
import dotenv from 'dotenv';
import readline from 'readline';

// Load environment variables
dotenv.config();

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

console.log('--- Active Directory Authentication Test ---');
console.log('This script will test direct authentication against your AD server');
console.log('Environment variables loaded:');
console.log('AD_URL:', process.env.AD_URL || 'NOT SET');
console.log('AD_BASE_DN:', process.env.AD_BASE_DN || 'NOT SET');
console.log('AD_USERNAME_SUFFIX:', process.env.AD_USERNAME_SUFFIX || 'NOT SET');

if (!process.env.AD_URL) {
  console.error('❌ AD_URL environment variable is not set');
  process.exit(1);
}

// Prompt for username and password
rl.question('\nEnter username (without domain): ', (username) => {
  rl.question('Enter password: ', (password) => {
    console.log('\nTesting authentication...');
    testAuthentication(username, password);
    rl.close();
  });
});

async function testAuthentication(username, password) {
  // Format the username with domain if needed
  let adUsername = username;
  
  if (process.env.AD_USERNAME_SUFFIX && !username.includes('@')) {
    adUsername = `${username}${process.env.AD_USERNAME_SUFFIX}`;
  }
  
  console.log('\n1. Testing with username format:', adUsername);
  
  // Also create backslash format for testing
  const domainName = process.env.AD_USERNAME_SUFFIX ? 
    process.env.AD_USERNAME_SUFFIX.replace('@', '') : 'domain';
  const backslashUsername = `${domainName}\\${username}`;
  
  // Configure AD connection
  const adConfig = {
    url: process.env.AD_URL,
    baseDN: process.env.AD_BASE_DN,
    username: adUsername,
    password: password,
    attributes: {
      user: ['dn', 'displayName', 'mail', 'sAMAccountName', 'cn', 'department', 'title', 'manager'],
      group: ['dn', 'cn', 'description']
    },
    tlsOptions: {
      rejectUnauthorized: false // Allow self-signed certificates
    },
    timeout: 5000, // 5 second timeout for operations
    connectTimeout: 10000 // 10 second timeout for initial connection
  };
  
  console.log('Config:', { ...adConfig, password: '******' });
  
  // Test @ format
  try {
    const ad = new ActiveDirectory(adConfig);
    
    console.log('\nAttempting authentication with @ format...');
    ad.authenticate(adUsername, password, (err, auth) => {
      if (err) {
        console.error('❌ Authentication error:', err.message);
        console.log('\n2. Testing with backslash format:', backslashUsername);
        testBackslashFormat();
        return;
      }
      
      if (auth) {
        console.log('✅ Authentication successful!');
        // Look up user details
        ad.findUser(username, (findErr, user) => {
          if (findErr) {
            console.warn('⚠️ User lookup warning:', findErr.message);
          } else if (!user) {
            console.warn('⚠️ User not found even though authentication succeeded');
          } else {
            console.log('✅ User found:', user.dn);
            console.log('Details:', {
              displayName: user.displayName || 'N/A',
              mail: user.mail || 'N/A',
              department: user.department || 'N/A',
              title: user.title || 'N/A'
            });
          }
        });
      } else {
        console.error('❌ Authentication failed but no error was thrown');
        console.log('\n2. Testing with backslash format:', backslashUsername);
        testBackslashFormat();
      }
    });
  } catch (error) {
    console.error('❌ Error creating ActiveDirectory instance:', error.message);
    console.log('\n2. Testing with backslash format:', backslashUsername);
    testBackslashFormat();
  }
  
  // Test backslash format
  function testBackslashFormat() {
    const adConfigBackslash = {
      ...adConfig,
      username: backslashUsername
    };
    
    try {
      const adBackslash = new ActiveDirectory(adConfigBackslash);
      
      adBackslash.authenticate(backslashUsername, password, (err, auth) => {
        if (err) {
          console.error('❌ Authentication error with backslash format:', err.message);
          showTroubleshooting();
          return;
        }
        
        if (auth) {
          console.log('✅ Authentication with backslash format successful!');
          // Look up user details
          adBackslash.findUser(username, (findErr, user) => {
            if (findErr) {
              console.warn('⚠️ User lookup warning:', findErr.message);
            } else if (!user) {
              console.warn('⚠️ User not found even though authentication succeeded');
            } else {
              console.log('✅ User found:', user.dn);
              console.log('Details:', {
                displayName: user.displayName || 'N/A',
                mail: user.mail || 'N/A',
                department: user.department || 'N/A',
                title: user.title || 'N/A'
              });
            }
            showTroubleshooting();
          });
        } else {
          console.error('❌ Authentication with backslash format failed but no error was thrown');
          showTroubleshooting();
        }
      });
    } catch (error) {
      console.error('❌ Error creating ActiveDirectory instance with backslash format:', error.message);
      showTroubleshooting();
    }
  }
  
  // Show troubleshooting guidance
  function showTroubleshooting() {
    console.log('\n--- Troubleshooting ---');
    console.log('If authentication failed, check these common issues:');
    console.log('1. Verify that your username and password are correct');
    console.log('2. Verify that AD_URL is correct and the LDAP server is reachable');
    console.log('3. Verify that AD_BASE_DN is correctly formatted');
    console.log('4. Verify that AD_USERNAME_SUFFIX matches your domain');
    console.log('5. Consider trying both formats: username@domain.com and domain\\username');
    console.log('6. If you\'re using SSL/TLS, verify that certificates are valid or set rejectUnauthorized: false');
    console.log('7. Check if there are any network issues or firewalls blocking the connection');
  }
}