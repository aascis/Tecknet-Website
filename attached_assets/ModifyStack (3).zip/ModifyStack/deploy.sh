#!/bin/bash
# deploy.sh - Deployment script for Ubuntu with Nginx

# Exit on error
set -e

# Default deployment directory
DEPLOY_DIR="/var/www/cloudservice"
DOMAIN="your-domain.com"  # Replace with your actual domain

# Display help if requested
if [ "$1" == "-h" ] || [ "$1" == "--help" ]; then
  echo "Usage: ./deploy.sh [options]"
  echo "Options:"
  echo "  --dir=/path/to/dir    Specify deployment directory (default: $DEPLOY_DIR)"
  echo "  --domain=example.com  Specify domain name for Nginx config"
  echo "  --ssl                 Set up SSL with Let's Encrypt"
  echo "  --help                Display this help message"
  exit 0
fi

# Parse arguments
for arg in "$@"; do
  case $arg in
    --dir=*)
    DEPLOY_DIR="${arg#*=}"
    shift
    ;;
    --domain=*)
    DOMAIN="${arg#*=}"
    shift
    ;;
    --ssl)
    SETUP_SSL=true
    shift
    ;;
    *)
    # Unknown option
    ;;
  esac
done

echo "=== SaaS Platform Deployment ==="
echo "Deployment directory: $DEPLOY_DIR"
echo "Domain: $DOMAIN"
echo "SSL setup: ${SETUP_SSL:-false}"
echo

# Check if running as root
if [ "$(id -u)" -ne 0 ]; then
  echo "This script needs to be run as root. Please use sudo."
  exit 1
fi

echo "=== Step 1: Installing dependencies ==="
apt update
apt install -y curl git build-essential nginx postgresql postgresql-contrib

# Install Node.js
echo "=== Step 2: Installing Node.js ==="
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Verify installations
echo "Node.js version: $(node -v)"
echo "npm version: $(npm -v)"

# Set up PostgreSQL
echo "=== Step 3: Setting up PostgreSQL ==="
systemctl start postgresql
systemctl enable postgresql

# Create database user and database
echo "Creating PostgreSQL user and database..."
sudo -i -u postgres bash << EOF
createuser --createdb cloudservice
psql -c "ALTER USER cloudservice WITH PASSWORD 'cloudservice_password';"
createdb -O cloudservice cloudservice
psql -c "GRANT ALL PRIVILEGES ON DATABASE cloudservice TO cloudservice;"
psql -d cloudservice -c "GRANT ALL ON SCHEMA public TO cloudservice;"
EOF

# Create deployment directory
echo "=== Step 4: Setting up deployment directory ==="
mkdir -p $DEPLOY_DIR
chown -R $(logname):$(logname) $DEPLOY_DIR

# Copy application files
echo "Copying application files..."
# Uncomment and modify if you're copying from a specific location
# cp -r /path/to/source/* $DEPLOY_DIR

cd $DEPLOY_DIR

# Install dependencies
echo "=== Step 5: Installing npm dependencies ==="
npm install
npm install -g tsx pm2

# Set up environment variables
echo "=== Step 6: Setting up environment variables ==="
cat > $DEPLOY_DIR/.env << EOF
# Database Configuration
DATABASE_URL=postgres://cloudservice:cloudservice_password@localhost:5432/cloudservice
PGUSER=cloudservice
PGPASSWORD=cloudservice_password
PGDATABASE=cloudservice
PGHOST=localhost
PGPORT=5432

# Session Configuration
SESSION_SECRET=$(openssl rand -hex 32)
NODE_ENV=production

# Active Directory Configuration
AD_URL=ldap://172.24.8.100:389
AD_BASE_DN=DC=tecknet,DC=ca
AD_USERNAME_SUFFIX=@tecknet.ca
AD_EMAIL_SUFFIX=@tecknet.ca

# Zammad Configuration
# ZAMMAD_API_URL=your_zammad_url
# ZAMMAD_API_TOKEN=your_zammad_token
# ZAMMAD_DEFAULT_GROUP=your_zammad_group
EOF

echo "=== Step 7: Building the application ==="
# Build the application
sh $DEPLOY_DIR/build.sh

echo "=== Step 8: Setting up database schema ==="
# Run database migrations
npm run db:push

echo "=== Step 9: Setting up PM2 ==="
# Start with PM2
pm2 start --name cloudservice --interpreter tsx server/index.ts
pm2 save
pm2 startup systemd
systemctl enable pm2-$(logname)

echo "=== Step 10: Setting up Nginx ==="
# Create Nginx configuration
cat > /etc/nginx/sites-available/cloudservice << EOF
server {
    listen 80;
    server_name $DOMAIN;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    # Increase the maximum request body size
    client_max_body_size 10M;
}
EOF

# Enable the site
ln -sf /etc/nginx/sites-available/cloudservice /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx

# Set up SSL if requested
if [ "$SETUP_SSL" = true ]; then
  echo "=== Step 11: Setting up SSL with Let's Encrypt ==="
  apt install -y certbot python3-certbot-nginx
  certbot --nginx -d $DOMAIN
  certbot renew --dry-run
fi

# Configure firewall
echo "=== Step 12: Setting up firewall ==="
ufw allow ssh
ufw allow 'Nginx Full'
ufw --force enable

echo "=== Deployment complete! ==="
echo "Your SaaS platform is now deployed at: http://$DOMAIN"
if [ "$SETUP_SSL" = true ]; then
  echo "Secure access available at: https://$DOMAIN"
fi

echo
echo "Management commands:"
echo "- View logs: pm2 logs cloudservice"
echo "- Restart application: pm2 restart cloudservice"
echo "- Update application: cd $DEPLOY_DIR && git pull && npm install && sh build.sh && pm2 restart cloudservice"