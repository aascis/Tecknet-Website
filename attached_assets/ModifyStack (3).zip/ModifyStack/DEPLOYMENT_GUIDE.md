# SaaS Platform Deployment Guide

This guide explains how to deploy and maintain the SaaS platform on an Ubuntu server with Nginx.

## Prerequisites

- Ubuntu server 18.04 LTS or newer
- Sudo/root access
- Domain name pointing to your server (optional but recommended)
- Network access to your Active Directory server (172.24.8.100)

## Deployment Options

### Option 1: Using the Automated Deployment Script

1. Upload the project files to your server (using SFTP, SCP, or by downloading the ZIP file)
2. Make the deployment script executable:
   ```bash
   chmod +x deploy.sh
   ```
3. Run the deployment script with sudo:
   ```bash
   sudo ./deploy.sh --domain=your-domain.com
   ```
   
   For SSL setup, add the `--ssl` flag:
   ```bash
   sudo ./deploy.sh --domain=your-domain.com --ssl
   ```

### Option 2: Manual Deployment

Follow these steps if you prefer to deploy manually or customize the deployment process:

1. **Prepare Server**
   ```bash
   sudo apt update
   sudo apt upgrade -y
   sudo apt install -y curl git build-essential nginx postgresql postgresql-contrib
   ```

2. **Install Node.js**
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
   sudo apt install -y nodejs
   ```

3. **Set up PostgreSQL**
   ```bash
   sudo -i -u postgres
   createuser --createdb cloudservice
   psql -c "ALTER USER cloudservice WITH PASSWORD 'your_secure_password';"
   createdb -O cloudservice cloudservice
   exit
   ```

4. **Set up the Application**
   ```bash
   sudo mkdir -p /var/www/cloudservice
   sudo chown -R $USER:$USER /var/www/cloudservice
   
   # Extract or copy files to the deployment directory
   unzip cloudservice.zip -d /var/www/cloudservice
   cd /var/www/cloudservice
   
   # Install dependencies
   npm install
   sudo npm install -g tsx pm2
   ```

5. **Set up Environment Variables**
   ```bash
   # Create .env file with appropriate values
   nano /var/www/cloudservice/.env
   ```

6. **Build and Set up Directory Structure**
   ```bash
   # Run the build script
   ./build.sh
   
   # Set up database
   npm run db:push
   ```

7. **Configure PM2**
   ```bash
   # Start application with PM2
   pm2 start --name cloudservice --interpreter tsx server/index.ts
   pm2 save
   pm2 startup systemd
   # Run the command that PM2 outputs
   ```

8. **Configure Nginx**
   ```bash
   # Create and edit Nginx configuration
   sudo nano /etc/nginx/sites-available/cloudservice
   
   # Enable site and restart Nginx
   sudo ln -s /etc/nginx/sites-available/cloudservice /etc/nginx/sites-enabled/
   sudo nginx -t
   sudo systemctl restart nginx
   ```

## Updating the Application

When you need to update the application:

1. **Using the Update Script** (recommended)
   ```bash
   ./update.sh
   ```

2. **Manual Update Process**
   ```bash
   cd /var/www/cloudservice
   
   # Backup .env
   cp .env .env.backup
   
   # If using Git
   git pull
   # Or extract new files
   
   # Install dependencies and build
   npm install
   ./build.sh
   
   # Apply migrations if needed
   npm run db:push
   
   # Restart application
   pm2 restart cloudservice
   ```

## Troubleshooting

If you encounter a blank screen after deployment:

1. **Check Server Logs**
   ```bash
   pm2 logs cloudservice
   sudo tail -f /var/log/nginx/error.log
   ```

2. **Verify Build Directory**
   ```bash
   # Make sure server/public directory exists and contains files
   ls -la /var/www/cloudservice/server/public
   
   # If missing, run the build script
   cd /var/www/cloudservice
   ./build.sh
   ```

3. **Test API Connectivity**
   ```bash
   curl http://localhost:5000/api/user -I
   ```

4. **Restart Services**
   ```bash
   pm2 restart cloudservice
   sudo systemctl restart nginx
   ```

## Important File Locations

- **Application Files**: `/var/www/cloudservice`
- **Environment Variables**: `/var/www/cloudservice/.env`
- **Nginx Configuration**: `/etc/nginx/sites-available/cloudservice`
- **PM2 Logs**: Access with `pm2 logs cloudservice`
- **Nginx Logs**: `/var/log/nginx/access.log` and `/var/log/nginx/error.log`

## Database Management

- **Connect to Database**:
  ```bash
  psql -U cloudservice -d cloudservice -h localhost
  ```

- **Backup Database**:
  ```bash
  pg_dump -U cloudservice cloudservice > backup_$(date +%Y-%m-%d).sql
  ```

- **Restore Database**:
  ```bash
  psql -U cloudservice -d cloudservice < backup_file.sql
  ```