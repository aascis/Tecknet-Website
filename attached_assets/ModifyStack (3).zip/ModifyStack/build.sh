#!/bin/bash
# build.sh - Build script for the SaaS platform

# Exit on error
set -e

echo "Starting build process..."

# Run the build command
npm run build

echo "Build completed. Creating necessary directories and links..."

# Create server/public directory if it doesn't exist
mkdir -p server/public

# Clear existing content
rm -rf server/public/*

# Copy the built files from dist/public to server/public
if [ -d "dist/public" ]; then
  cp -r dist/public/* server/public/
  echo "Successfully copied build files from dist/public to server/public"
else
  echo "Error: dist/public directory not found after build"
  exit 1
fi

echo "Build and setup complete!"
echo
echo "To run the application in production mode:"
echo "  NODE_ENV=production tsx server/index.ts"
echo
echo "To run with PM2:"
echo "  pm2 start --name cloudservice --interpreter tsx server/index.ts -- --prod"