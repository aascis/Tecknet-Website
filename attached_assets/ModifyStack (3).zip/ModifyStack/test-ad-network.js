// Test network connectivity to AD server
import net from 'net';
import dns from 'dns';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Extract host and port from AD_URL
// Format expected: ldap://host:port
const adUrl = process.env.AD_URL || '';
const match = adUrl.match(/ldap:\/\/([^:]+):(\d+)/);

if (!match) {
  console.error('❌ Invalid AD_URL format:', adUrl);
  console.error('Expected format: ldap://hostname:port');
  process.exit(1);
}

const [, host, port] = match;
const portNum = parseInt(port, 10);

console.log('--- Testing AD Server Network Connectivity ---');
console.log('AD_URL:', adUrl);
console.log('Host:', host);
console.log('Port:', portNum);

// Check if we can resolve the hostname
console.log('\n1. Testing DNS resolution...');
dns.lookup(host, (err, address) => {
  if (err) {
    console.error(`❌ DNS resolution failed: ${err.message}`);
    return;
  }
  
  console.log(`✅ DNS resolution successful: ${host} resolves to ${address}`);
  
  // Try to establish a TCP connection to the AD server
  console.log('\n2. Testing TCP connection to LDAP port...');
  const socket = new net.Socket();
  
  // Set a timeout for the connection attempt
  socket.setTimeout(5000);
  
  socket.on('connect', () => {
    console.log(`✅ Successfully connected to ${host}:${portNum}`);
    console.log('   This confirms network connectivity to the AD server.');
    socket.end();
  });
  
  socket.on('timeout', () => {
    console.error(`❌ Connection to ${host}:${portNum} timed out`);
    console.error('   Possible causes:');
    console.error('   - Firewall blocking the connection');
    console.error('   - AD server not running or not listening on this port');
    console.error('   - Network latency issues');
    socket.destroy();
  });
  
  socket.on('error', (connectionError) => {
    console.error(`❌ Connection error: ${connectionError.message}`);
    console.error('   Possible causes:');
    console.error('   - Firewall blocking the connection');
    console.error('   - Incorrect hostname or port');
    console.error('   - AD server not running');
    console.error('   - No route to host (network issue)');
  });
  
  // Attempt to connect
  socket.connect(portNum, host);
});